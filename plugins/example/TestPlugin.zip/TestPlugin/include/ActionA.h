// Example of a plugin action

#pragma once

class ccMainAppInterface;

namespace Test
{
	void	performActionA( ccMainAppInterface *appInterface );
}
